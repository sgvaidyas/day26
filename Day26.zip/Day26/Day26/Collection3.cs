﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Rect
    {
        public int len, bred;
        public Rect(int x,int y)
        {
            len = x;
            bred = y;
        }
        public string display()
        {
            return ("LEN = " +len + " breadth = " +bred);
        }
    }
    class Collection3
    {
        static void Main(string[] args)
        {
            var obj = new List<Rect>();
            Rect ob = new Rect(3,5);
            obj.Add(new Rect(3,4));
            obj.Add(new Rect(55, 66));
            obj.Add(ob);

            foreach (Rect r in obj)
                Console.WriteLine(r.display());
        }
    }
}
