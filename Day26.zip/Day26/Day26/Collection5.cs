﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Collection5
    {
        static void Main(string[] args)
        {
            //Dictionary<string, int> players = new Dictionary<string, int>();
            SortedDictionary<string, int> players = new SortedDictionary<string, int>();
            players.Add("Chandan", 30);
            players.Add("Akash", 32);
            players.Add("Mamatha", 12);
            players.Add("Ashwini", 22);
            players.Add("Praveen", 19);

            foreach (KeyValuePair<string,int> ob in players)
                Console.WriteLine("PLAYER  = " + ob.Key + " = " + ob.Value);

            Console.WriteLine("\n\n");
            foreach (KeyValuePair<string, int> ob in players.OrderBy(key => key.Value))
            {
                Console.WriteLine("Key: {0}, Value: {1}", ob.Key, ob.Value);
            }

        }
    }
}
