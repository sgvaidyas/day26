﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Collection6
    {
        static void Main(string[] args)
        {
            var num = new HashSet<int>();

            num.Add(22);
            num.Add(33);
            num.Add(12);
            num.Add(11);
            num.Add(22);

            foreach(var n in num)
                Console.WriteLine(n);

        }
    }
}
