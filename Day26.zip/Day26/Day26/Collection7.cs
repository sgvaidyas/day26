﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Mytemplate<T>
    {
        public Mytemplate(T ob)
        {
            Console.WriteLine("you passed " + ob);
        }
    }
    class Collection7
    {
        static void Main(string[] args)
        {
            Mytemplate<int> ob = new Mytemplate<int>(444);
            Mytemplate<string> ob1 = new Mytemplate<string>("my string");

        }
    }
}
