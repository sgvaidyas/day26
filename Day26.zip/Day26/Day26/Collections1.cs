﻿using System;
using System.Collections.Generic;

namespace Day26
{
    class Collections1
    {
        static void Main(string[] args)
        {
            var states = new LinkedList<string>();

            states.AddFirst("Kerela");
            states.AddFirst("Kerela");
            LinkedListNode<string> nd = states.Find("Kerela");
            states.AddBefore(nd, "Andra");
            LinkedListNode<string> nd1 = states.Find("Kerela");
            states.AddAfter(nd1, "Tamilnadu");
            states.AddLast("Karnataka");


            foreach (string n in states)
                Console.WriteLine(n);
        }
    }
}
