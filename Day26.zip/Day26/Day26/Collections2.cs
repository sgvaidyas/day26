﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Collections2
    {
        static void Main(string[] args)
        {
            var countries = new List<string>();

            countries.Add("India");
            countries.Add("China");
            countries.Add("Japan");
            countries.Add("Japan");
            countries.Add("AustraliA");


            foreach (string n in countries)
                Console.WriteLine(n);

            countries.Insert(2, "America");
            Console.WriteLine("_______________________");
            foreach (string n in countries)
                Console.WriteLine(n);

            countries.RemoveAt(3);
            Console.WriteLine("_______________________");
            foreach (string n in countries)
                Console.WriteLine(n);

            countries.RemoveAll(callme);

            Console.WriteLine("_______________________");
            foreach (string n in countries)
                Console.WriteLine(n);       

        }
        static bool callme(String s)
        {
            return s.ToUpper().EndsWith("A");
        }
    }
}
