﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Collections4cs
    {
        static void Main(string[] args)
        {

            var fruits = new SortedSet<string>();

            fruits.Add("Apple");
            fruits.Add("Orange");
            fruits.Add("Mango");
            fruits.Add("Orange");
            fruits.Add("Mango");

            foreach(var x in fruits)
                Console.WriteLine(x);

            Console.WriteLine("\n\n");
            var Cities = new SortedSet<string>() { "Bangalore","Chennai","Hyderabad","Kolkatta","Panji"};
            
            foreach (var x in Cities)
                Console.WriteLine(x);

            var Cities1 = Cities.Reverse();
            Console.WriteLine("\n\n");
            foreach (var x in Cities1)
                Console.WriteLine(x);


        }
    }
}
