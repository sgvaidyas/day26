﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Day26
{
    class File2
    {
        static void Main(string[] args)
        {
            FileStream file = new FileStream("E:\\myfile.txt", FileMode.Create);
            StreamWriter s = new StreamWriter(file);

            Console.WriteLine("Enter a line =");
            string line = Console.ReadLine();

            s.WriteLine(line);           


            s.Close();
            file.Close();

        }
    }
}
