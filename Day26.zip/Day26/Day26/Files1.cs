﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Day26
{
    class Files1
    {
        static void Main(string[] args)
        {
            FileStream file = new FileStream("E:\\abc.txt",FileMode.Open);

            StreamReader s = new StreamReader(file);
            string line;
            while( (line = s.ReadLine()) != null)
            {
                Console.WriteLine(line);
            }       
            
            s.Close();
            file.Close();
        }
    }
}
