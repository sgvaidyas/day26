﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class Addition<T>
    {
        public T Add(T eval1, T eval2)
        {

            dynamic a = eval1;
            dynamic b = eval2;
            T result = a + b;
            return result;
        }
    }
    class Generic1
    {
    }
}
