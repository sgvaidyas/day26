﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day26
{
    class game1
    {
        static void reset(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = 0;
            }
        }
        static void display(int[] a)
        {
            for(int i=0;i<a.Length;i++)
            {
                if(i%3==0)
                    Console.WriteLine();
                Console.Write(a[i]+"\t");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] a = new int[9];
            reset(a);
            int p1 = 1;
            int pos = 0;
            a[3] = p1;
            display(a);
            int[] p = { 3, 6 ,  7 ,  8 ,  5 ,  2 ,  1 ,  0,   4};
            
            bool flag = true;
            int dice,ind,prevpos;
            while(flag)
            {
                Console.WriteLine("Enter dice val (1-4)");
                dice = int.Parse(Console.ReadLine());
                prevpos = p[pos];
                a[prevpos] = 0;
                pos = pos + dice;
                ind = p[pos];
                a[ind] = p1;
                display(a);
                if (pos >= 8)
                    flag = false;
            }
        }
    }
}
